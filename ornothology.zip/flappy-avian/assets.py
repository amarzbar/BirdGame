"""
Asset loader module.
Handles downloading, caching, and loading images from online sources.
"""

import os
import urllib.request
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Warning: PIL not available, using fallback graphics")
import config


class AssetLoader:
    """Manages downloading and loading of game assets."""
    
    def __init__(self):
        """Initialize the asset loader and create assets directory."""
        self.assets_dir = config.ASSETS_DIR
        self.loaded_assets = {}
        self._ensure_assets_directory()
    
    def _ensure_assets_directory(self):
        """Create assets directory if it doesn't exist."""
        if not os.path.exists(self.assets_dir):
            os.makedirs(self.assets_dir)
    
    def _get_local_path(self, asset_name):
        """Get the local file path for an asset.
        
        Args:
            asset_name: Name of the asset (e.g., 'background', 'bird')
            
        Returns:
            Local file path as string
        """
        return os.path.join(self.assets_dir, f"{asset_name}.png")
    
    def _download_asset(self, url, local_path):
        """Download an asset from URL to local path.
        
        Args:
            url: URL to download from
            local_path: Local path to save to
            
        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"Downloading {local_path}...")
            urllib.request.urlretrieve(url, local_path)
            print(f"Downloaded {local_path}")
            return True
        except Exception as e:
            print(f"Error downloading {url}: {e}")
            return False
    
    def _load_image(self, local_path, size=None):
        """Load an image from local path.
        
        Args:
            local_path: Path to the image file
            size: Optional tuple (width, height) to resize to
            
        Returns:
            PhotoImage object
        """
        if not PIL_AVAILABLE:
            return None
            
        try:
            img = Image.open(local_path)
            if size:
                img = img.resize(size, Image.LANCZOS)
            return ImageTk.PhotoImage(img)
        except Exception as e:
            print(f"Error loading {local_path}: {e}")
            return None
    
    def load_asset(self, asset_name, size=None):
        """Load an asset, downloading if necessary.
        
        Args:
            asset_name: Name of the asset from config.ASSET_URLS
            size: Optional tuple (width, height) to resize to
            
        Returns:
            PhotoImage object or None if failed
        """
        # Check if already loaded
        cache_key = f"{asset_name}_{size}"
        if cache_key in self.loaded_assets:
            return self.loaded_assets[cache_key]
        
        # Get URL and local path
        if asset_name not in config.ASSET_URLS:
            print(f"Unknown asset: {asset_name}")
            return None
        
        url = config.ASSET_URLS[asset_name]
        local_path = self._get_local_path(asset_name)
        
        # Download if not exists
        if not os.path.exists(local_path):
            if not self._download_asset(url, local_path):
                return None
        
        # Load image
        image = self._load_image(local_path, size)
        if image:
            self.loaded_assets[cache_key] = image
        
        return image
    
    def load_rotated_asset(self, asset_name, size=None, angle=0):
        """Load an asset with rotation.
        
        Args:
            asset_name: Name of the asset from config.ASSET_URLS
            size: Optional tuple (width, height) to resize to
            angle: Rotation angle in degrees (counter-clockwise)
            
        Returns:
            PhotoImage object or None if failed
        """
        if not PIL_AVAILABLE:
            return None
        
        # Get URL and local path
        if asset_name not in config.ASSET_URLS:
            print(f"Unknown asset: {asset_name}")
            return None
        
        cache_key = f"{asset_name}_{size}_{angle}"
        if cache_key in self.loaded_assets:
            return self.loaded_assets[cache_key]
        
        url = config.ASSET_URLS[asset_name]
        local_path = self._get_local_path(asset_name)
        
        # Download if not exists
        if not os.path.exists(local_path):
            if not self._download_asset(url, local_path):
                return None
        
        # Load and rotate image
        try:
            img = Image.open(local_path)
            if size:
                img = img.resize(size, Image.LANCZOS)
            if angle != 0:
                img = img.rotate(angle, expand=True)
            photo_image = ImageTk.PhotoImage(img)
            self.loaded_assets[cache_key] = photo_image
            return photo_image
        except Exception as e:
            print(f"Error loading rotated {local_path}: {e}")
            return None
    
    def load_all_assets(self):
        """Load all game assets with appropriate sizes.
        
        Returns:
            Dictionary of asset_name -> PhotoImage
        """
        assets = {}
        
        # Load background
        assets['background'] = self.load_asset(
            'background',
            (config.WINDOW_WIDTH, config.WINDOW_HEIGHT)
        )
        
        # Load ground
        assets['ground'] = self.load_asset(
            'ground',
            (config.WINDOW_WIDTH, config.GROUND_HEIGHT)
        )
        
        # Load pipe (normal, for bottom pipes)
        assets['pipe'] = self.load_asset(
            'pipe',
            (config.PIPE_WIDTH, config.WINDOW_HEIGHT)
        )
        
        # Load rotated pipe (180 degrees, for top pipes)
        assets['pipe_top'] = self.load_rotated_asset(
            'pipe',
            (config.PIPE_WIDTH, config.WINDOW_HEIGHT),
            180
        )
        
        # Load bird
        assets['bird'] = self.load_asset(
            'bird',
            (config.BIRD_SIZE, config.BIRD_SIZE)
        )
        
        return assets
