# Flappy Bird Clone - Architecture Diagram

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                          main.py                             │
│                    (Entry Point: 23 lines)                   │
│                                                               │
│  • Creates tkinter root window                              │
│  • Instantiates FlappyBirdGame                              │
│  • Starts main event loop                                   │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ creates
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                         game.py                              │
│                   (Game Loop: 311 lines)                     │
│                                                               │
│  FlappyBirdGame Class:                                       │
│  • Manages game states (menu/playing/game_over)             │
│  • Handles input (space/enter/R keys)                       │
│  • Main game loop (60 FPS)                                  │
│  • Orchestrates updates & rendering                         │
└─────┬────────┬────────┬────────┬────────┬──────────────────┘
      │        │        │        │        │
      │ uses   │ uses   │ uses   │ uses   │ uses
      ▼        ▼        ▼        ▼        ▼
┌─────────┐ ┌──────┐ ┌───────┐ ┌──────────┐ ┌─────────┐
│ bird.py │ │pipe.py│ │score_ │ │collision.│ │assets.py│
│         │ │       │ │manager│ │   py     │ │         │
│         │ │       │ │  .py  │ │          │ │         │
└────┬────┘ └───┬──┘ └───┬───┘ └─────┬────┘ └────┬────┘
     │          │        │            │            │
     │ reads    │ reads  │ reads      │ reads      │ reads
     ▼          ▼        ▼            ▼            ▼
     ┌──────────────────────────────────────────────────┐
     │                  config.py                        │
     │             (Constants: 56 lines)                 │
     │                                                    │
     │  • Window dimensions & FPS                       │
     │  • Physics constants (gravity, jump, max speed)  │
     │  • Pipe settings (width, gap, speed)             │
     │  • Bird color palette                            │
     │  • Asset URLs & file paths                       │
     │  • Game state constants                          │
     └──────────────────────────────────────────────────┘
```

## Module Dependencies

```
main.py
  └── game.py
        ├── bird.py ────────┐
        │                   │
        ├── pipe.py ────────┤
        │                   │
        ├── score_manager.py├──► config.py
        │                   │
        ├── collision.py ───┤
        │                   │
        └── assets.py ──────┘
```

## Data Flow

### Game Loop Flow

```
┌──────────────────────────────────────────────────────────┐
│                     Game Loop (60 FPS)                    │
└──────────────────────────────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          │                               │
          ▼                               ▼
┌──────────────────┐          ┌──────────────────────┐
│  UPDATE PHASE    │          │   RENDER PHASE       │
│                  │          │                      │
│  1. Bird.update()│          │  1. Clear canvas     │
│     • Apply      │          │  2. Draw background  │
│       gravity    │          │  3. Draw pipes       │
│     • Update Y   │          │  4. Draw ground      │
│     • Calculate  │          │  5. Draw bird        │
│       rotation   │          │  6. Draw score       │
│                  │          │  7. Draw UI          │
│  2. PipeManager  │          │     (menu/gameover)  │
│     .update()    │          │                      │
│     • Move pipes │          │                      │
│     • Spawn new  │          │                      │
│     • Remove old │          │                      │
│                  │          │                      │
│  3. Check score  │          │                      │
│     • Bird pass  │          │                      │
│       pipe?      │          │                      │
│     • Update     │          │                      │
│       score      │          │                      │
│                  │          │                      │
│  4. Check        │          │                      │
│     collisions   │          │                      │
│     • Bird vs    │          │                      │
│       pipes      │          │                      │
│     • Bird vs    │          │                      │
│       ground     │          │                      │
│     • Bird vs    │          │                      │
│       ceiling    │          │                      │
│                  │          │                      │
│  5. Update       │          │                      │
│     ground scroll│          │                      │
└──────────────────┘          └──────────────────────┘
```

## Class Relationships

```
FlappyBirdGame
    │
    ├── has-a ───► Bird
    │               ├── x, y (position)
    │               ├── velocity
    │               ├── color
    │               └── rotation
    │
    ├── has-a ───► PipeManager
    │               └── contains ───► List[Pipe]
    │                                  ├── x (position)
    │                                  ├── gap_center
    │                                  ├── top_height
    │                                  └── scored
    │
    ├── has-a ───► ScoreManager
    │               ├── current_score
    │               └── high_score
    │
    └── has-a ───► AssetLoader
                    └── loaded_assets
                        ├── background
                        ├── ground
                        ├── pipe
                        └── bird
```

## Input Flow

```
User Input (Keyboard)
        │
        ▼
┌──────────────────┐
│  tkinter event   │
│    handlers      │
└────────┬─────────┘
         │
         ├──► Space Key ──────► game._on_space_press()
         │                           │
         │                           ▼
         │                      bird.jump() ◄─── NEEDS IMPLEMENTATION!
         │
         ├──► Enter Key ──────► game._on_enter_press()
         │                           │
         │                           ▼
         │                      game._start_game()
         │
         └──► R Key ──────────► game._on_restart_press()
                                     │
                                     ▼
                                game._start_game()
```

## State Machine

```
        ┌──────────┐
        │   MENU   │
        └─────┬────┘
              │
              │ Press ENTER
              ▼
        ┌──────────┐
        │ PLAYING  │◄─────┐
        └─────┬────┘      │
              │           │
              │ Collision │ Press R
              ▼           │
        ┌──────────┐      │
        │GAME_OVER │──────┘
        └──────────┘
```

## Asset Loading Flow

```
Game Start
    │
    ▼
AssetLoader.load_all_assets()
    │
    ├──► For each asset (background, ground, pipe, bird):
    │       │
    │       ├──► Check if exists in cache (assets/ folder)
    │       │       │
    │       │       ├─► Yes ──► Load from disk
    │       │       │              │
    │       │       └─► No ───► Download from URL
    │       │                      │
    │       │                      └─► Save to cache
    │       │
    │       ├──► Load with PIL.Image
    │       │
    │       ├──► Resize to appropriate dimensions
    │       │
    │       └──► Convert to PhotoImage
    │
    └──► Return dictionary of loaded assets
```

## Score Persistence Flow

```
Game Start
    │
    ▼
ScoreManager.__init__()
    │
    └──► _load_high_score()
            │
            ├─► Check if highscore.txt exists
            │       │
            │       ├─► Yes ──► Read score
            │       │
            │       └─► No ───► Return 0
            │
            └─► Store in self.high_score

... Game plays ...

Bird passes pipe
    │
    ▼
ScoreManager.add_score(1)
    │
    ├──► current_score += 1
    │
    └──► If current_score > high_score:
            │
            ├──► high_score = current_score
            │
            └──► _save_high_score()
                    │
                    └──► Write to highscore.txt
```

## Collision Detection Flow

```
Game Update
    │
    ▼
collision.check_all_collisions(bird, pipes)
    │
    ├──► check_bird_ground_collision(bird)
    │       │
    │       └──► bird.y + size/2 >= ground_y ?
    │
    ├──► check_bird_ceiling_collision(bird)
    │       │
    │       └──► bird.y - size/2 <= 0 ?
    │
    └──► check_bird_pipe_collision(bird, pipes)
            │
            └──► For each pipe:
                    │
                    ├──► Get bird_rect
                    │
                    ├──► Get pipe top_rect
                    │
                    ├──► Get pipe bottom_rect
                    │
                    ├──► rects_collide(bird_rect, top_rect) ?
                    │
                    └──► rects_collide(bird_rect, bottom_rect) ?

If any collision:
    │
    └──► game.state = STATE_GAME_OVER
```

## Physics System

```
Every Frame (60 FPS):

Bird Physics:
    │
    ├──► velocity += GRAVITY (0.5)
    │       │
    │       └─► velocity increases (bird falls faster)
    │
    ├──► if velocity > MAX_FALL_SPEED (10.0):
    │       │
    │       └─► velocity = MAX_FALL_SPEED
    │
    ├──► y += velocity
    │       │
    │       └─► Bird moves down (or up if velocity negative)
    │
    └──► rotation = -velocity * 3
            │
            └─► Bird tilts based on velocity

On Jump (NEEDS IMPLEMENTATION):
    │
    └──► velocity = JUMP_VELOCITY (-9.0)
            │
            └─► Negative velocity = upward movement!
```

## Summary

- **Total Modules**: 8 Python files
- **Total Lines**: ~1,035 lines
- **Architecture Style**: Object-Oriented with Modular Design
- **Design Patterns**: State Machine, Resource Manager, Single Responsibility
- **Dependencies**: tkinter (built-in), Pillow (external)
- **Key Feature Missing**: Bird jump implementation (intentional exercise)
