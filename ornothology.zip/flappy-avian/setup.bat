@echo off
REM Setup script for Windows

echo ====================================
echo Flappy Bird Setup Script for Windows
echo ====================================
echo.

REM Check Python version
echo Checking Python installation...
python --version >nul 2>&1
if %errorlevel% == 0 (
    for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYTHON_VERSION=%%i
    echo [OK] Python %PYTHON_VERSION% found
    set PYTHON_CMD=python
) else (
    echo [ERROR] Python not found!
    echo.
    echo Please install Python 3.9 or newer:
    echo   1. Go to https://www.python.org/downloads/
    echo   2. Download the latest Python installer
    echo   3. Run installer and CHECK "Add Python to PATH"
    echo   4. Restart this script
    echo.
    pause
    exit /b 1
)

REM Check pip
echo.
echo Checking pip...
%PYTHON_CMD% -m pip --version >nul 2>&1
if %errorlevel% == 0 (
    echo [OK] pip is installed
) else (
    echo [ERROR] pip not found!
    echo Installing pip...
    %PYTHON_CMD% -m ensurepip --default-pip
)

REM Install Pillow
echo.
echo Installing Pillow library...
%PYTHON_CMD% -c "import PIL" >nul 2>&1
if %errorlevel% == 0 (
    echo [OK] Pillow is already installed
) else (
    echo Installing Pillow...
    %PYTHON_CMD% -m pip install Pillow
    
    if %errorlevel% == 0 (
        echo [OK] Pillow installed successfully
    ) else (
        echo [ERROR] Failed to install Pillow
        echo Try manually: %PYTHON_CMD% -m pip install Pillow
        pause
        exit /b 1
    )
)

REM Check tkinter
echo.
echo Checking tkinter (GUI library)...
%PYTHON_CMD% -c "import tkinter" >nul 2>&1
if %errorlevel% == 0 (
    echo [OK] tkinter is installed
) else (
    echo [ERROR] tkinter not found!
    echo.
    echo Tkinter should come with Python by default.
    echo You may need to reinstall Python and make sure
    echo "tcl/tk and IDLE" is checked during installation.
)

REM Test the game
echo.
echo ====================================
echo Setup complete!
echo ====================================
echo.
echo To run the game:
echo   %PYTHON_CMD% main.py
echo.
echo To fix the jump function (for the assignment):
echo   1. Open bird.py in a text editor (Notepad, VS Code, etc.)
echo   2. Find the jump() method
echo   3. Add this line: self.velocity = config.JUMP_VELOCITY
echo.
echo Press any key to try running the game now...
pause >nul

REM Try to run the game
%PYTHON_CMD% main.py
