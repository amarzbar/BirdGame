"""
Score manager module.
Handles current score and persistent high score storage.
"""

import os
import config


class ScoreManager:
    """Manages game scoring and high score persistence."""
    
    def __init__(self):
        """Initialize the score manager."""
        self.current_score = 0
        self.high_score = self._load_high_score()
    
    def _load_high_score(self):
        """Load high score from file.
        
        Returns:
            High score as integer, or 0 if file doesn't exist
        """
        if not os.path.exists(config.HIGH_SCORE_FILE):
            return 0
        
        try:
            with open(config.HIGH_SCORE_FILE, 'r') as f:
                score = int(f.read().strip())
                return score
        except (ValueError, IOError) as e:
            print(f"Error loading high score: {e}")
            return 0
    
    def _save_high_score(self):
        """Save high score to file."""
        try:
            with open(config.HIGH_SCORE_FILE, 'w') as f:
                f.write(str(self.high_score))
        except IOError as e:
            print(f"Error saving high score: {e}")
    
    def add_score(self, points):
        """Add points to current score.
        
        Args:
            points: Number of points to add
        """
        self.current_score += points
        
        # Update high score if needed
        if self.current_score > self.high_score:
            self.high_score = self.current_score
            self._save_high_score()
    
    def reset_current_score(self):
        """Reset current score to 0 for new game."""
        self.current_score = 0
    
    def get_current_score(self):
        """Get the current score.
        
        Returns:
            Current score as integer
        """
        return self.current_score
    
    def get_high_score(self):
        """Get the high score.
        
        Returns:
            High score as integer
        """
        return self.high_score
    
    def render_score(self, canvas, x, y, show_high_score=False):
        """Render score on canvas.
        
        Args:
            canvas: tkinter Canvas object
            x: X position for score text
            y: Y position for score text
            show_high_score: If True, also show high score
        """
        # Draw current score with shadow for better visibility
        canvas.create_text(
            x + 2, y + 2,
            text=str(self.current_score),
            font=('Arial', 48, 'bold'),
            fill='black'
        )
        canvas.create_text(
            x, y,
            text=str(self.current_score),
            font=('Arial', 48, 'bold'),
            fill='white'
        )
        
        # Draw high score if requested
        if show_high_score:
            high_score_y = y + 60
            canvas.create_text(
                x + 1, high_score_y + 1,
                text=f"Best: {self.high_score}",
                font=('Arial', 20),
                fill='black'
            )
            canvas.create_text(
                x, high_score_y,
                text=f"Best: {self.high_score}",
                font=('Arial', 20),
                fill='gold'
            )
