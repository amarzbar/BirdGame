#!/bin/bash
# Flappy Bird Game Launcher
# Use this script to run the game with the correct Python version

cd "$(dirname "$0")"
/opt/homebrew/bin/python3.12 main.py
