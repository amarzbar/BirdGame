# Flappy Bird Game - Setup Instructions for Students

## What You Need

This game requires:
1. **Python 3.9 or newer** - The programming language
2. **Pillow library** - For displaying images
3. **A code editor** (VS Code recommended, but any text editor works)

---

## Setup Instructions by Operating System

### 🍎 macOS

#### Step 1: Check if Python is installed
1. Open **Terminal** (search for it in Spotlight)
2. Type: `python3 --version`
3. If you see a version number like `Python 3.9.x` or higher, you're good!

#### Step 2: Install Python (if needed)
If Python isn't installed:
1. Go to [python.org/downloads](https://www.python.org/downloads/)
2. Download the latest Python installer for Mac
3. Run the installer and follow the instructions
4. **OR** use Homebrew: `brew install python3`

#### Step 3: Install Pillow
In Terminal, type:
```bash
python3 -m pip install --user Pillow
```

#### Step 4: Run the game
```bash
cd path/to/flappy-avian
python3 main.py
```

**If you get a tkinter error on macOS:**
You may need Python from Homebrew:
```bash
brew install python-tk@3.12
/opt/homebrew/bin/python3.12 main.py
```

---

### 🪟 Windows

#### Step 1: Check if Python is installed
1. Open **Command Prompt** (search for "cmd" in Start menu)
2. Type: `python --version`
3. If you see a version number like `Python 3.9.x` or higher, you're good!

#### Step 2: Install Python (if needed)
If Python isn't installed:
1. Go to [python.org/downloads](https://www.python.org/downloads/)
2. Download the latest Python installer for Windows
3. **IMPORTANT:** Check the box that says "Add Python to PATH"
4. Click "Install Now"

#### Step 3: Install Pillow
In Command Prompt, type:
```bash
python -m pip install Pillow
```

#### Step 4: Run the game
```bash
cd path\to\flappy-avian
python main.py
```

---

### 💻 ChromeOS / Chromebook

ChromeOS has limited Python support, but you have options:

#### Option 1: Use Linux (Beta) - Recommended
1. Go to **Settings** → **Advanced** → **Developers**
2. Turn on **Linux (Beta)**
3. Wait for Linux to install
4. Open the **Linux Terminal**
5. Install Python:
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-tk
   ```
6. Install Pillow:
   ```bash
   pip3 install Pillow
   ```
7. Run the game:
   ```bash
   cd path/to/flappy-avian
   python3 main.py
   ```

#### Option 2: Use an Online IDE
If Linux Beta doesn't work, try online:
- **Replit.com** (free, runs in browser)
  1. Create a new Python repl
  2. Upload all the game files
  3. Click "Run"
- **Google Colab** (free, but not ideal for games)

---

## 🎮 Running the Game

Once everything is set up:

1. **Navigate to the game folder** in your terminal/command prompt
2. **Run the game:**
   - macOS/Linux: `python3 main.py`
   - Windows: `python main.py`
3. **Play!**
   - Press **SPACEBAR** to start
   - Press **SPACEBAR** to make the bird jump
   - Try to get the highest score!

---

## 🔧 Troubleshooting

### "python: command not found" or "python3: command not found"
- **Windows:** Make sure you checked "Add Python to PATH" during installation
- **Mac/Linux:** Try `python3` instead of `python`

### "No module named 'PIL'"
- Run: `python -m pip install Pillow` (or `python3 -m pip install Pillow`)

### "No module named 'tkinter'"
- **macOS:** Install Python from Homebrew with `brew install python-tk@3.12`
- **Linux:** Run `sudo apt install python3-tk`
- **Windows:** Reinstall Python and make sure "tcl/tk and IDLE" is checked

### The game window is too small or too large
- Edit `config.py` and change `WINDOW_WIDTH` and `WINDOW_HEIGHT`

### The game runs but I can't jump
- You need to complete the assignment! Look at `bird.py` and fix the `jump()` method

---

## 📝 For the Assignment

### Before you start coding:
1. Make a **copy** of the original files (backup!)
2. Open the project in a code editor
3. Read through `QUICKSTART.md` to understand the code structure

### Files you'll be editing:
- `bird.py` - This is where you'll fix the jump function!

### Testing your code:
After making changes, save the file and run:
```bash
python3 main.py
```

---

## 🆘 Need Help?

1. **Read the error message** - It usually tells you what's wrong
2. **Check your code** - Did you save the file?
3. **Ask a teacher or parent** - Show them the error message
4. **Google the error** - Copy and paste it into Google

---

## 🎯 Quick Start Checklist

- [ ] Python is installed and working
- [ ] Pillow library is installed
- [ ] I can open a terminal/command prompt
- [ ] I can navigate to the game folder
- [ ] The game runs (even if the bird doesn't jump yet)
- [ ] I have a code editor open
- [ ] I'm ready to fix the code!

---

**Good luck and have fun coding! 🚀**
