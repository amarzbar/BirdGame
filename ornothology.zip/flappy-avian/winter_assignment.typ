#set document(title: "Flappy Bird Code Analysis - Winter Break Assignment")
#set page(
  paper: "us-letter",
  margin: (x: 1in, y: 1in),
  numbering: "1",
)
// Dyslexic-friendly settings: sans-serif font, larger size, more spacing
#set text(font: "Comic Sans MS", size: 13pt)
#set heading(numbering: "1.")
#set par(justify: false, leading: 0.8em, spacing: 1.2em)

#align(center)[
  #text(size: 22pt, weight: "bold")[
Wisdom and Widgets  
]
  
  #v(0.3em)
  
  #text(size: 18pt)[
    Exploring Video Game Code
  ]
  
  #v(0.3em)
  
  #text(size: 14pt)[
    Understanding Variables, Conditions, and Loops
  ]
  
  #v(1em)
  
  #line(length: 100%, stroke: 2pt)
]

#v(1.5em)

#text(weight: "bold", size: 14pt)[Student Name:] #box(width: 3.5in, line(length: 100%, stroke: 0.5pt))

#v(0.8em)

#text(weight: "bold", size: 14pt)[Date:] #box(width: 2.5in, line(length: 100%, stroke: 0.5pt))

#v(1.5em)

= Introduction

Welcome! In this assignment, you'll explore a real Python game - Flappy Bird! 

You'll learn how programmers use *variables*, *if statements*, *loops*, and *lists* to make games work.

Don't worry if you don't understand everything at first. Take your time and do your best!

*Files you'll look at:*
- `config.py` - Game settings
- `bird.py` - How the bird moves
- `pipe.py` - The obstacles
- `game.py` - Main game code

#v(1em)

*Tips:*
- Read the code carefully
- Ask for help if you're stuck
- Use a pencil so you can erase

#pagebreak()

= Section 1: Understanding Variables (10 points)

Variables are like boxes that store information. Let's find some!

== Question 1.1 (2 points)

Open the file called `config.py`. Look for a line that says `GRAVITY = 0.5`

*What type of number is 0.5?* Circle one:

#v(0.3em)
#grid(
  columns: 2,
  gutter: 2em,
  [#box(width: 2in)[A) Whole number (integer)]],
  [#box(width: 2in)[B) Decimal number (float)]],
)
#v(1em)

== Question 1.2 (2 points)

Still in `config.py`, find the line `JUMP_VELOCITY = -9.0`

*Write the number you see here:*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Why do you think this number is negative? (Hint: Think about which way is "up" on a screen)*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 1.3 (3 points)

Find the list called `BIRD_COLORS` in `config.py`. It looks like this:
```python
BIRD_COLORS = [
    '#FF6B6B',  # Red
    '#4ECDC4',  # Teal
    ...
]
```

*Part A: Count how many colors are in the list.*

#v(0.3em)
Answer: #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Each color starts with a \# symbol. What do you think these codes represent?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 1.4 (3 points)

Open `bird.py` and find the `__init__` method. Look at these lines:
```python
self.x = x
self.y = y
self.velocity = 0
```

*These are the bird's variables. What do you think each one stores?*

#v(0.3em)
#table(
  columns: (2fr, 3fr),
  stroke: 0.5pt,
  inset: 0.5em,
  [*Variable*], [*What it stores*],
  [`self.x`], [#v(1em)],
  [`self.y`], [#v(1em)],
  [`self.velocity`], [#v(1em)],
)

#pagebreak()

= Section 2: If Statements (Conditionals) (12 points)

If statements help the computer make decisions!

== Question 2.1 (4 points)

Open `bird.py` and find the `update()` method. Look for this code:
```python
if self.velocity > config.MAX_FALL_SPEED:
    self.velocity = config.MAX_FALL_SPEED
```

*Part A: In your own words, what is this code checking?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: What happens if the condition is true?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 2.2 (4 points)

In `game.py`, find the `_on_space_press` method. You'll see:
```python
if self.state == config.STATE_PLAYING:
    self.bird.jump()
```

*Part A: When does the bird jump?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Why is this check important? What would happen without it?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 2.3 (4 points)

Open `collision.py` and look at the `check_bird_ground_collision` function:
```python
def check_bird_ground_collision(bird):
    ground_y = config.WINDOW_HEIGHT - config.GROUND_HEIGHT
    bird_bottom = bird.y + bird.size // 2
    return bird_bottom >= ground_y
```

*Part A: What two things is this comparing?*

1. #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

2. #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#v(1em)

*Part B: When would this return `True`? (What does it mean if the function returns True?)*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#pagebreak()

= Section 3: Lists and Collections (10 points)

Lists help us store multiple things together!

== Question 3.1 (3 points)

Open `pipe.py` and find the `PipeManager` class. Look at the `__init__` method:
```python
def __init__(self):
    self.pipes = []
```

*Part A: What does `[]` mean in Python?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Why do you think we need a list to store pipes?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 3.2 (4 points)

Still in `pipe.py`, find this line in the `update` method:
```python
self.pipes = [p for p in self.pipes if not p.is_off_screen()]
```

This removes pipes that went off the screen.

*Part A: Why is it important to remove old pipes?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: What would happen if we never removed pipes?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 3.3 (3 points)

In `config.py`, look at the `BIRD_COLORS` list again.

*Write code to add your favorite color to this list:*

```python
BIRD_COLORS.append(                                    )
```

#v(0.3em)
Your answer: #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#pagebreak()

= Section 4: Loops (Repeating Actions) (12 points)

Loops let us do the same thing multiple times!

== Question 4.1 (4 points)

Open `pipe.py` and find the `render` method in `PipeManager`:
```python
for pipe in self.pipes:
    pipe.render(canvas, pipe_image, pipe_top_image)
```

*Part A: If there are 3 pipes in the list, how many times will `pipe.render()` run?*

#v(0.3em)
Answer: #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: In your own words, what is this loop doing?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 4.2 (4 points)

Find the `check_scoring` method in `PipeManager`:
```python
score_gained = 0
for pipe in self.pipes:
    if not pipe.scored and bird_x > pipe.x + pipe.width:
        pipe.scored = True
        score_gained += 1
return score_gained
```

*Part A: What does `score_gained += 1` mean?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: When does the score increase?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 4.3 (4 points)

Open `game.py` and find the `_game_loop` method:
```python
def _game_loop(self):
    if self.state == config.STATE_PLAYING:
        self._update_game()
    self._render()
    self.root.after(1000 // config.FPS, self._game_loop)
```

*Part A: This method calls itself at the end. What do you think this creates?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: If FPS = 60, how many times per second does the game loop run?*

#v(0.3em)
Answer: #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#pagebreak()

= Section 5: Math in Code (10 points)

Let's see how the game uses math!

== Question 5.1 (4 points)

Open `bird.py` and look at the `update` method:
```python
self.velocity += config.GRAVITY
self.y += self.velocity
```

Imagine the bird starts with:
- `velocity = 0`
- `y = 100`
- `GRAVITY = 0.5`

*Calculate what happens after 2 frames:*

#v(0.3em)
Frame 1:
- velocity = 0 + 0.5 = #box(width: 1.5in, height: 2em, stroke: 0.5pt, inset: 0.3em)[]
- y = 100 + #box(width: 1in, height: 2em, stroke: 0.5pt, inset: 0.3em)[] = #box(width: 1.5in, height: 2em, stroke: 0.5pt, inset: 0.3em)[]

#v(1em)
Frame 2:
- velocity = #box(width: 1in, height: 2em, stroke: 0.5pt, inset: 0.3em)[] + 0.5 = #box(width: 1.5in, height: 2em, stroke: 0.5pt, inset: 0.3em)[]
- y = #box(width: 1in, height: 2em, stroke: 0.5pt, inset: 0.3em)[] + #box(width: 1in, height: 2em, stroke: 0.5pt, inset: 0.3em)[] = #box(width: 1.5in, height: 2em, stroke: 0.5pt, inset: 0.3em)[]

#v(1em)

== Question 5.2 (3 points)

In `config.py`, find these values:
- `PIPE_GAP = 180` (space between pipes)
- `BIRD_SIZE = 34` (size of bird)

*How much extra space does the bird have when flying through a pipe?*

#v(0.3em)
Calculation: 180 - 34 = #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[] pixels

#v(1em)

== Question 5.3 (3 points)

Still in `config.py`:
- `WINDOW_WIDTH = 400`
- `GROUND_SPEED = 3`

*How many frames does it take for the ground to scroll completely across the screen?*

#v(0.3em)
Calculation: 400 ÷ 3 = #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[] frames


= Section 6: Reading and Understanding Code (10 points)

== Question 6.1 (5 points)

Open `bird.py` and find the `jump` method:
```python
def jump(self):
    self.velocity = config.JUMP_VELOCITY
```

*Part A: What does this method do to the bird's velocity?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Remember that `JUMP_VELOCITY = -9.0`. Why is it negative?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 6.2 (5 points)

Look at `score_manager.py` and find the `add_score` method:
```python
def add_score(self, points):
    self.current_score += points
    if self.current_score > self.high_score:
        self.high_score = self.current_score
        self._save_high_score()
```

*Part A: What happens when you beat your high score?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Why is it useful to save the high score?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

= Section 7: Making Changes (12 points)

Now let's think about how to modify the game!

== Question 7.1 (4 points)

You want to make the game easier by making the bird jump higher.

*Part A: Which file would you change?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Which variable would you change?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part C: Would you make the number bigger or smaller? Why?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 7.2 (4 points)

You want to make the pipes move slower.

*Part A: Find `PIPE_SPEED` in `config.py`. What is its current value?*

#v(0.3em)
Answer: #box(width: 2in, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: To make pipes move slower, should you increase or decrease this number?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 7.3 (4 points)

You want to add a new color to the bird choices.

*Write the code you would add to `config.py`:*

#v(0.3em)
```python
BIRD_COLORS.append(                                    )
```
#v(1em)
Your answer: #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Pick any color you like! You can search "hex color codes" online to find colors.*

#pagebreak()

= Section 8: Thinking Like a Programmer (10 points)

== Question 8.1 (5 points)

Look at the whole codebase. The game is split into different files:
- `bird.py` - Just about the bird
- `pipe.py` - Just about the pipes
- `game.py` - Puts everything together

*Why do you think programmers split code into different files instead of putting everything in one big file?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 8.2 (5 points)

Think about how the game works. 

*Describe in your own words what happens when you press the spacebar to make the bird jump. Try to include at least 3 steps.*

#v(0.3em)
1. #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#v(1em)
2. #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#v(1em)
3. #box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]

#pagebreak()

= Section 9: Fix the Code! (14 points)

== Question 9.1 (14 points)

*IMPORTANT: The jump functionality is broken!* 

When you run the game and press the spacebar, the bird doesn't jump. Your job is to fix it!

Open `bird.py` and find the `jump` method. It looks like this:

```python
def jump(self):
    # TODO: Make the bird jump!
    pass # This basically tells the program to do nothing!
```

*Part A: What is the current problem with this code? (3 points)*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Part B: Write the code to fix the jump method: (8 points)*

#v(0.3em)
```python
def jump(self):
```
#box(width: 100%, height: 6em, stroke: 0.5pt, inset: 0.3em)[
  #text(fill: gray, size: 11pt)[Write your code here...]
]

#v(1em)

*Part C: After you fix it, test the game. Does the bird jump now? (1 point)*

Circle one: #h(2em) YES #h(3em) NO

#v(1em)

*Part D: Explain in your own words why your fix works. (2 points)*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]


= Bonus Challenge! (5 extra points)

== Bonus Question (5 points)

If you could add ONE new feature to this game, what would it be?

*Describe your feature:*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Which file(s) would you need to change to add this feature?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

*Draw a picture of what your feature would look like in the game:*

#v(0.3em)
#box(width: 100%, height: 15em, stroke: 0.5pt)

#v(2em)

= Reflection

== Question 1
*What was the most interesting thing you learned from this assignment?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 2
*What was the most confusing part?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

== Question 3
*Do you want to learn more about coding? Why or why not?*

#v(0.3em)
#box(width: 100%, height: 4em, stroke: 0.5pt, inset: 0.3em)[]
#v(1em)

#align(center)[
  #line(length: 100%, stroke: 2pt)
  
  #v(1em)
  
  #text(size: 16pt, weight: "bold")[Great Job!]
  
  #v(0.3em)
  
  Total Points: 100 + 5 Bonus = 105 Points
  
  #v(1em)
  
  #line(length: 100%, stroke: 2pt)
]
