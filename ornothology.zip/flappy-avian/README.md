# Flappy Bird Clone - Python Exercise

A modularized Flappy Bird clone built with Python and tkinter, featuring online sprite loading, high score persistence, and randomized bird colors.

## 📦 For Teachers/Instructors

**Distributing to Students:**

This project works on **Windows, macOS, Linux, and ChromeOS (with Linux Beta)**. 

**Quick Setup for Students:**
1. Share this entire folder with students (zip it up)
2. Students should read: **`HOW_TO_RUN.txt`** (simplest guide)
3. Students run the appropriate setup script:
   - Windows: `setup.bat` (double-click)
   - Mac/Linux: `setup.sh` (run in Terminal)
4. Students complete the assignment in `winter_assignment.pdf`

**What Students Need:**
- Python 3.9+ (free from python.org)
- Pillow library (auto-installed by setup scripts)
- A text editor (Notepad, VS Code, etc.)

**The Assignment:**
- The `jump()` function in `bird.py` is intentionally broken
- Students must implement it to make the bird jump
- See `winter_assignment.pdf` for the full assignment

## 🎮 Features

- **Classic Flappy Bird gameplay** with physics-based movement
- **Online sprite loading** - Downloads bird, pipe, and background sprites from the internet
- **Persistent high scores** - Your best score is saved between sessions
- **Randomized bird colors** - Each game features a different colored bird
- **Modular architecture** - Clean, single-purpose files (each under 1000 lines)
- **Smooth animations** - 60 FPS game loop

## 📁 Project Structure

```
flappy-avian/
├── main.py              # Entry point - launches the game
├── game.py              # Main game class with game loop and rendering
├── bird.py              # Bird class with physics and rendering
├── pipe.py              # Pipe and PipeManager classes
├── collision.py         # Collision detection logic
├── score_manager.py     # Score tracking and persistence
├── assets.py            # Asset downloading and loading
├── config.py            # Game constants and configuration
├── assets/              # Downloaded sprites (auto-created)
└── highscore.txt        # High score storage (auto-created)
```

## 🚀 Installation

1. **Clone or download this repository**

2. **Install required dependencies:**
   ```bash
   pip install pillow
   ```
   
   Note: `tkinter` comes pre-installed with most Python distributions. If you don't have it:
   - **macOS**: Already included
   - **Windows**: Already included with Python installer
   - **Linux**: `sudo apt-get install python3-tk`

3. **Run the game:**
   ```bash
   python main.py
   ```

## 🎯 Controls

- **ENTER** - Start game from menu
- **SPACE** - Make the bird flap/jump (needs implementation - see below!)
- **R** - Restart after game over

## 🔨 YOUR TASK: Implement Bird Jumping!

This project is intentionally missing **ONE** critical feature as a learning exercise:

**The bird's jumping/flapping mechanic is not implemented!**

### What You Need to Do:

Open `bird.py` and find the `jump()` method around line 53. You'll see:

```python
def jump(self):
    """Make the bird jump/flap.
    
    EXERCISE FOR THE READER:
    Implement this method to make the bird jump when spacebar is pressed.
    
    Hint: You need to set self.velocity to config.JUMP_VELOCITY
    This will give the bird an upward velocity (remember: negative Y is up)
    
    TODO: Implement the jump logic here
    """
    # TODO: Your code here!
    # Hint: self.velocity = ?
    pass
```

### Hints:

1. **Gravity is already working** - The bird falls naturally due to `update()` method
2. **The spacebar is already bound** - In `game.py`, pressing space calls `bird.jump()`
3. **The jump velocity is configured** - Check `config.JUMP_VELOCITY` (it's negative because Y increases downward)
4. **You only need ONE line of code!** - Set `self.velocity` to the jump velocity

### Solution Check:

Once implemented correctly:
- Pressing SPACE should make the bird jump upward
- The bird should fall back down due to gravity
- You should be able to navigate through pipes
- The game should be fully playable!

## 🎨 How It Works

### Physics System
- **Gravity**: Constant downward acceleration applied each frame
- **Velocity**: Bird's speed increases as it falls
- **Jump**: Instant upward velocity applied on spacebar press
- **Max Fall Speed**: Velocity is capped to prevent excessive speed

### Asset Loading
1. On first run, sprites are downloaded from GitHub
2. Images are cached in the `assets/` folder
3. Subsequent runs load from cache (faster!)
4. Sprites are resized to fit the game window

### Scoring System
- **+1 point** for each pipe successfully passed
- **High score** automatically saved to `highscore.txt`
- Score displayed during gameplay
- Both current and high score shown on game over

### Collision Detection
- Rectangle-based collision detection
- Checks bird vs pipes, ground, and ceiling
- Collision ends the game instantly

## 🎓 Learning Objectives

This project demonstrates:

1. **Object-Oriented Programming**
   - Classes for game entities (Bird, Pipe, etc.)
   - Encapsulation of related functionality
   - Clean interfaces between modules

2. **Game Development Fundamentals**
   - Game loop pattern
   - State management (menu, playing, game over)
   - Frame-based animation
   - Collision detection

3. **Python Best Practices**
   - Module organization
   - Configuration management
   - File I/O for persistence
   - Error handling

4. **Real-World Skills**
   - Downloading resources from the internet
   - Caching for performance
   - Working with external libraries (PIL, tkinter)
   - Code modularization (single responsibility principle)

## 🐛 Troubleshooting

**Game won't start:**
- Make sure PIL/Pillow is installed: `pip install pillow`
- Check that you have internet connection for first run (to download sprites)

**Sprites not loading:**
- Check your internet connection
- Try deleting the `assets/` folder and restarting (forces re-download)
- Fallback colored shapes will be used if sprites fail to load

**Bird won't jump:**
- That's expected! Complete the exercise in `bird.py` to fix it 😉

## 🎉 After Completing the Exercise

Once you've implemented the jump function, try these challenges:

1. **Add sound effects** - Play a sound when jumping or scoring
2. **Add difficulty progression** - Make pipes move faster as score increases
3. **Add bird animation** - Rotate the bird based on velocity
4. **Add different backgrounds** - Cycle through day/night themes
5. **Add power-ups** - Temporary invincibility or slow-motion

## 📜 License

This is an educational project. Feel free to use, modify, and learn from it!

## 🙏 Credits

- Sprites from [samuelcust/flappy-bird-assets](https://github.com/samuelcust/flappy-bird-assets)
- Original Flappy Bird by Dong Nguyen

---

**Happy Coding! 🐦**
