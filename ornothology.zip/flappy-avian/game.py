"""
Main game class module.
Handles game loop, state management, rendering, and user input.
"""

import tkinter as tk
from bird import Bird
from pipe import PipeManager
from score_manager import ScoreManager
from assets import AssetLoader
import collision
import config


class FlappyBirdGame:
    """Main game class managing the game loop and state."""
    
    def __init__(self, root):
        """Initialize the game.
        
        Args:
            root: tkinter root window
        """
        self.root = root
        self.root.title("Flappy Bird Clone")
        self.root.resizable(False, False)
        
        # Create canvas
        self.canvas = tk.Canvas(
            root,
            width=config.WINDOW_WIDTH,
            height=config.WINDOW_HEIGHT,
            bg='skyblue'
        )
        self.canvas.pack()
        
        # Game state
        self.state = config.STATE_MENU
        self.ground_x = 0  # For scrolling ground effect
        
        # Initialize game objects
        self.bird = Bird(100, config.WINDOW_HEIGHT // 2)
        self.pipe_manager = PipeManager()
        self.score_manager = ScoreManager()
        
        # Load assets
        self.asset_loader = AssetLoader()
        self.assets = {}
        self._load_assets()
        
        # Bind controls
        self._bind_controls()
        
        # Start game loop
        self._game_loop()
    
    def _load_assets(self):
        """Load all game assets."""
        print("Loading game assets...")
        self.assets = self.asset_loader.load_all_assets()
        print("Assets loaded!")
    
    def _bind_controls(self):
        """Bind keyboard controls."""
        # Space bar for jump
        self.root.bind('<space>', self._on_space_press)
        
        # R for restart
        self.root.bind('r', self._on_restart_press)
        
        # Enter to start from menu
        self.root.bind('<Return>', self._on_enter_press)
    
    def _on_space_press(self, event):
        """Handle space bar press.
        
        Args:
            event: tkinter event object
        """
        if self.state == config.STATE_PLAYING:
            # EXERCISE: This is where the bird should jump!
            # The bird.jump() method needs to be implemented
            self.bird.jump()
    
    def _on_restart_press(self, event):
        """Handle R key press for restart.
        
        Args:
            event: tkinter event object
        """
        if self.state == config.STATE_GAME_OVER:
            self._start_game()
    
    def _on_enter_press(self, event):
        """Handle Enter key press to start game.
        
        Args:
            event: tkinter event object
        """
        if self.state == config.STATE_MENU:
            self._start_game()
    
    def _start_game(self):
        """Start a new game."""
        self.state = config.STATE_PLAYING
        self.bird.reset(100, config.WINDOW_HEIGHT // 2)
        self.pipe_manager.reset()
        self.score_manager.reset_current_score()
        self.ground_x = 0
    
    def _game_loop(self):
        """Main game loop."""
        if self.state == config.STATE_PLAYING:
            self._update_game()
        
        self._render()
        
        # Schedule next frame
        self.root.after(1000 // config.FPS, self._game_loop)
    
    def _update_game(self):
        """Update game state."""
        # Update bird physics
        self.bird.update()
        
        # Update pipes
        self.pipe_manager.update()
        
        # Check for scoring
        score_gained = self.pipe_manager.check_scoring(self.bird.x)
        if score_gained > 0:
            self.score_manager.add_score(score_gained)
        
        # Update ground scroll
        self.ground_x -= config.GROUND_SPEED
        if self.ground_x <= -config.WINDOW_WIDTH:
            self.ground_x = 0
        
        # Check collisions
        if collision.check_all_collisions(self.bird, self.pipe_manager.pipes):
            self.state = config.STATE_GAME_OVER
    
    def _render(self):
        """Render the game."""
        # Clear canvas
        self.canvas.delete('all')
        
        # Draw background
        if self.assets.get('background'):
            self.canvas.create_image(0, 0, image=self.assets['background'], anchor='nw')
        else:
            self.canvas.create_rectangle(
                0, 0, config.WINDOW_WIDTH, config.WINDOW_HEIGHT,
                fill='#4EC0CA'
            )
        
        # Draw pipes
        if self.state != config.STATE_MENU:
            self.pipe_manager.render(
                self.canvas, 
                self.assets.get('pipe'),
                self.assets.get('pipe_top')
            )
        
        # Draw ground
        ground_y = config.WINDOW_HEIGHT - config.GROUND_HEIGHT
        if self.assets.get('ground'):
            # Draw two grounds for scrolling effect
            self.canvas.create_image(
                self.ground_x, ground_y,
                image=self.assets['ground'],
                anchor='nw'
            )
            self.canvas.create_image(
                self.ground_x + config.WINDOW_WIDTH, ground_y,
                image=self.assets['ground'],
                anchor='nw'
            )
        else:
            self.canvas.create_rectangle(
                0, ground_y,
                config.WINDOW_WIDTH, config.WINDOW_HEIGHT,
                fill='#DED895',
                outline='#C6BE7D',
                width=2
            )
        
        # Draw bird
        if self.state != config.STATE_MENU:
            self.bird.render(self.canvas, self.assets.get('bird'))
        
        # Draw score
        if self.state == config.STATE_PLAYING:
            self.score_manager.render_score(
                self.canvas,
                config.WINDOW_WIDTH // 2,
                50
            )
        
        # Draw UI based on state
        if self.state == config.STATE_MENU:
            self._render_menu()
        elif self.state == config.STATE_GAME_OVER:
            self._render_game_over()
    
    def _render_menu(self):
        """Render the main menu."""
        # Title with shadow
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2 + 3,
            config.WINDOW_HEIGHT // 2 - 97,
            text="FLAPPY BIRD",
            font=('Arial', 36, 'bold'),
            fill='black'
        )
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2,
            config.WINDOW_HEIGHT // 2 - 100,
            text="FLAPPY BIRD",
            font=('Arial', 36, 'bold'),
            fill='yellow'
        )
        
        # Instructions
        instructions = [
            "Press ENTER to Start",
            "",
            "Press SPACE to Flap",
            "(Not yet implemented - Exercise!)",
            "",
            "Press R to Restart"
        ]
        
        y_offset = config.WINDOW_HEIGHT // 2
        for i, line in enumerate(instructions):
            color = 'white' if i != 3 else 'orange'
            self.canvas.create_text(
                config.WINDOW_WIDTH // 2 + 1,
                y_offset + i * 30 + 1,
                text=line,
                font=('Arial', 14),
                fill='black'
            )
            self.canvas.create_text(
                config.WINDOW_WIDTH // 2,
                y_offset + i * 30,
                text=line,
                font=('Arial', 14),
                fill=color
            )
        
        # High score
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2 + 1,
            config.WINDOW_HEIGHT - 51,
            text=f"High Score: {self.score_manager.get_high_score()}",
            font=('Arial', 20),
            fill='black'
        )
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2,
            config.WINDOW_HEIGHT - 50,
            text=f"High Score: {self.score_manager.get_high_score()}",
            font=('Arial', 20),
            fill='gold'
        )
    
    def _render_game_over(self):
        """Render the game over screen."""
        # Semi-transparent overlay
        self.canvas.create_rectangle(
            0, 0, config.WINDOW_WIDTH, config.WINDOW_HEIGHT,
            fill='black',
            stipple='gray50'
        )
        
        # Game Over text
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2 + 3,
            config.WINDOW_HEIGHT // 2 - 97,
            text="GAME OVER",
            font=('Arial', 40, 'bold'),
            fill='black'
        )
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2,
            config.WINDOW_HEIGHT // 2 - 100,
            text="GAME OVER",
            font=('Arial', 40, 'bold'),
            fill='red'
        )
        
        # Score display
        self.score_manager.render_score(
            self.canvas,
            config.WINDOW_WIDTH // 2,
            config.WINDOW_HEIGHT // 2,
            show_high_score=True
        )
        
        # Restart instruction
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2 + 1,
            config.WINDOW_HEIGHT // 2 + 121,
            text="Press R to Restart",
            font=('Arial', 18),
            fill='black'
        )
        self.canvas.create_text(
            config.WINDOW_WIDTH // 2,
            config.WINDOW_HEIGHT // 2 + 120,
            text="Press R to Restart",
            font=('Arial', 18),
            fill='white'
        )
