"""
Collision detection module.
Handles all collision detection logic for the game.
"""

import config


def rects_collide(rect1, rect2):
    """Check if two rectangles collide.
    
    Args:
        rect1: Tuple of (x, y, width, height)
        rect2: Tuple of (x, y, width, height)
        
    Returns:
        True if rectangles overlap, False otherwise
    """
    x1, y1, w1, h1 = rect1
    x2, y2, w2, h2 = rect2
    
    # Check if rectangles don't overlap (return False)
    # If they don't NOT overlap, then they do overlap (return True)
    return not (x1 + w1 < x2 or  # rect1 is left of rect2
                x2 + w2 < x1 or  # rect2 is left of rect1
                y1 + h1 < y2 or  # rect1 is above rect2
                y2 + h2 < y1)    # rect2 is above rect1


def check_bird_pipe_collision(bird, pipes):
    """Check if bird collides with any pipe.
    
    Args:
        bird: Bird object
        pipes: List of Pipe objects
        
    Returns:
        True if collision detected, False otherwise
    """
    bird_rect = bird.get_rect()
    
    for pipe in pipes:
        top_rect, bottom_rect = pipe.get_rects()
        
        # Check collision with top pipe
        if rects_collide(bird_rect, top_rect):
            return True
        
        # Check collision with bottom pipe
        if rects_collide(bird_rect, bottom_rect):
            return True
    
    return False


def check_bird_ground_collision(bird):
    """Check if bird collides with the ground.
    
    Args:
        bird: Bird object
        
    Returns:
        True if collision detected, False otherwise
    """
    ground_y = config.WINDOW_HEIGHT - config.GROUND_HEIGHT
    bird_bottom = bird.y + bird.size // 2
    
    return bird_bottom >= ground_y


def check_bird_ceiling_collision(bird):
    """Check if bird collides with the ceiling.
    
    Args:
        bird: Bird object
        
    Returns:
        True if collision detected, False otherwise
    """
    bird_top = bird.y - bird.size // 2
    return bird_top <= 0


def check_all_collisions(bird, pipes):
    """Check all possible collisions for the bird.
    
    Args:
        bird: Bird object
        pipes: List of Pipe objects
        
    Returns:
        True if any collision detected, False otherwise
    """
    # Check ground collision
    if check_bird_ground_collision(bird):
        return True
    
    # Check ceiling collision
    if check_bird_ceiling_collision(bird):
        return True
    
    # Check pipe collisions
    if check_bird_pipe_collision(bird, pipes):
        return True
    
    return False
