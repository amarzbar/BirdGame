#!/bin/bash
# Setup script for macOS/Linux

echo "🐦 Flappy Bird Setup Script for macOS/Linux"
echo "============================================"
echo ""

# Check Python version
echo "Checking Python installation..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    echo "✓ Python $PYTHON_VERSION found"
    PYTHON_CMD="python3"
else
    echo "✗ Python 3 not found!"
    echo ""
    echo "Please install Python 3.9 or newer:"
    echo "  macOS: brew install python3"
    echo "  Linux: sudo apt install python3 python3-pip python3-tk"
    exit 1
fi

# Check pip
echo ""
echo "Checking pip..."
if $PYTHON_CMD -m pip --version &> /dev/null; then
    echo "✓ pip is installed"
else
    echo "✗ pip not found!"
    echo "Installing pip..."
    $PYTHON_CMD -m ensurepip --default-pip
fi

# Install Pillow
echo ""
echo "Installing Pillow library..."
if $PYTHON_CMD -c "import PIL" &> /dev/null; then
    echo "✓ Pillow is already installed"
else
    echo "Installing Pillow..."
    $PYTHON_CMD -m pip install --user Pillow
    
    if [ $? -eq 0 ]; then
        echo "✓ Pillow installed successfully"
    else
        echo "✗ Failed to install Pillow"
        echo "Try manually: $PYTHON_CMD -m pip install --user Pillow"
        exit 1
    fi
fi

# Check tkinter
echo ""
echo "Checking tkinter (GUI library)..."
if $PYTHON_CMD -c "import tkinter" &> /dev/null; then
    echo "✓ tkinter is installed"
else
    echo "✗ tkinter not found!"
    echo ""
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macOS detected. You may need Python from Homebrew:"
        echo "  brew install python-tk@3.12"
        echo ""
        echo "After installing, run the game with:"
        echo "  /opt/homebrew/bin/python3.12 main.py"
    else
        echo "Linux detected. Install tkinter with:"
        echo "  sudo apt install python3-tk"
    fi
fi

# Test the game
echo ""
echo "Setup complete! 🎉"
echo ""
echo "To run the game:"
echo "  $PYTHON_CMD main.py"
echo ""
echo "To fix the jump function (for the assignment):"
echo "  1. Open bird.py in a text editor"
echo "  2. Find the jump() method"
echo "  3. Add: self.velocity = config.JUMP_VELOCITY"
echo ""
echo "Press Enter to try running the game now, or Ctrl+C to exit..."
read

# Try to run the game
$PYTHON_CMD main.py
