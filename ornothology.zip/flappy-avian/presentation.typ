#set page(
  paper: "presentation-16-9",
  margin: (x: 2em, y: 2em),
)
#set text(font: "Arial", size: 20pt)

// Slide 1: Title
#align(center + horizon)[
  #text(size: 48pt, weight: "bold")[
    Flappy Bird Code Investigation
  ]
  
  #v(1em)
  
  #text(size: 32pt)[
    A Winter Break Coding Adventure
  ]
  
  #v(2em)
  
  #text(size: 24pt)[
    Understanding How Games Work
  ]
]

#pagebreak()

// Slide 2: What is Flappy Bird?
#v(1em)
= What is Flappy Bird?

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    *A Simple But Fun Game:*
    - Tap spacebar to make the bird jump
    - Avoid the pipes
    - Try to get the highest score!
    - Each round, the bird changes color
    
    #v(1em)
    
    *Your Mission:*
    
    Explore the Python code that makes this game work!
  ],
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.22.33 AM.png", height: 280pt)
    ]
  ]
)

#pagebreak()

// Slide 3: Game in Action
#align(center + horizon)[
  #v(1em)
  #text(size: 28pt, weight: "bold")[The Game in Action]
  
  #v(1em)
  
  #image("assets/Screenshot 2025-12-06 at 10.24.58 AM.png", width: 70%)
  
  #v(1em)
  
  *Notice:* The bird, pipes, background, and score display
]

#pagebreak()

// Slide 4: How Code Works
#v(1em)
= How Does the Code Work?

#text(size: 24pt)[
  The game is split into different files - each one has a specific job!
]

#v(1em)

#grid(
  columns: (1fr, 1fr),
  gutter: 1em,
  rows: (auto, auto),
  row-gutter: 1em,
  
  box(fill: blue.lighten(80%), inset: 1em, radius: 8pt)[
    #align(center)[
      *config.py*
      
      #v(0.5em)
      
      Game settings & constants
    ]
  ],
  
  box(fill: red.lighten(80%), inset: 1em, radius: 8pt)[
    #align(center)[
      *bird.py*
      
      #v(0.5em)
      
      How the bird moves
    ]
  ],
  
  box(fill: green.lighten(80%), inset: 1em, radius: 8pt)[
    #align(center)[
      *pipe.py*
      
      #v(0.5em)
      
      Creating obstacles
    ]
  ],
  
  box(fill: yellow.lighten(60%), inset: 1em, radius: 8pt)[
    #align(center)[
      *game.py*
      
      #v(0.5em)
      
      Putting it all together
    ]
  ],
)

#pagebreak()

// Slide 5: Meet the Bird
#v(1em)
= Meet the Bird! 🐦

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    #align(center)[
      #image("assets/bird.png", height: 320pt)
    ]
  ],
  [
    *The bird has:*
    
    - A position (x, y)
    - A velocity (speed)
    - A size
    - A color (random each game!)
    
    #v(1em)
    
    *The bird can:*
    
    - Fall down (gravity)
    - Jump up (when you press space)
    - Rotate as it moves
    
    #v(1em)
    
    #text(size: 18pt, fill: blue)[
      *All of this is controlled by code in `bird.py`!*
    ]
  ]
)

#pagebreak()

// Slide 6: Understanding Gravity
#v(1em)
= Understanding Gravity

#align(center)[
  #text(size: 24pt)[
    *What makes the bird fall?*
  ]
]

#v(1em)

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.26.47 AM.png", height: 280pt)
    ]
  ],
  [
    *Gravity in Code:*
    
    ```python
    GRAVITY = 0.5
    
    # Every frame:
    velocity += GRAVITY
    y += velocity
    ```
    
    #v(1em)
    
    - Gravity pulls the bird down
    - Velocity gets faster over time
    - The bird moves down the screen
    
    #v(1em)
    
    *Try changing GRAVITY to see what happens!*
  ]
)

#pagebreak()

// Slide 7: The Pipes Challenge
#align(center + horizon)[
  #text(size: 28pt, weight: "bold")[The Pipes Challenge 🚧]
  
  #v(1em)
  
  #image("assets/pipe.png", width: 60%)
  
  #v(1em)
  
  #text(size: 22pt)[
    *Question:* How does the game create and manage multiple pipes?
  ]
]

#pagebreak()

// Slide 8: Pipes Using Lists
#align(center + horizon)[
  #text(size: 28pt, weight: "bold")[Pipes: Using Lists!]
  
  #v(1em)
  
  *The game uses a LIST:*
  
  #v(0.5em)
  
  ```python
  pipes = []
  
  # Add new pipes
  pipes.append(new_pipe)
  
  # Move all pipes
  for pipe in pipes:
      pipe.update()
  
  # Remove old pipes
  pipes = [p for p in pipes
           if not p.off_screen()]
  ```
  
  #v(1em)
  
  Lists let us store multiple pipes and work with them all at once!
]

#pagebreak()

// Slide 9: Collision Detection
#v(1em)
= Collision Detection 💥

#align(center)[
  #text(size: 24pt)[
    *How does the game know when the bird hits a pipe?*
  ]
]

#v(1em)

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.26.47 AM.png", height: 280pt)
    ]
  ],
  [
    *Rectangle Collision:*
    
    - Bird has a box around it
    - Each pipe has boxes
    - Check if boxes overlap
    
    #v(1em)
    
    ```python
    if bird_box touches pipe_box:
        game_over = True
    ```
    
    #v(1em)
    
    *The code checks this 60 times per second!*
  ]
)

#pagebreak()

// Slide 11: Keeping Score
#v(1em)
= Keeping Score 🏆

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    *How scoring works:*
    
    1. Bird starts at x = 100
    2. Pipes scroll from right to left
    3. When bird passes a pipe:
       - Check if bird.x > pipe.x
       - Add 1 point!
       - Mark pipe as "scored"
    
    #v(1em)
    
    *High Score:*
    - Saved to a file
    - Loads when you restart
    - Try to beat it!
  ],
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.24.58 AM.png", height: 320pt)
    ]
  ]
)

#pagebreak()

// Slide 11: The Game Loop
#align(center + horizon)[
  #text(size: 28pt, weight: "bold")[The Game Loop 🔄]
  
  #v(1em)
  
  #text(size: 24pt)[
    *Every game runs in a loop - 60 times per second!*
  ]
  
  #v(1em)
  
  #box(
    width: 80%,
    fill: blue.lighten(90%),
    inset: 1.5em,
    radius: 8pt
  )[
    #text(size: 20pt)[
      ```python
      while game_running:
          1. Check for input (space pressed?)
          2. Update bird position
          3. Update pipe positions
          4. Check for collisions
          5. Update score
          6. Draw everything
          7. Wait 1/60th of a second
          8. Repeat!
      ```
    ]
  ]
  
  #v(1em)
  
  #text(size: 20pt, fill: red)[
    *This loop is the HEART of the game!*
  ]
]

#pagebreak()

// Slide 14: Variables
#v(1em)
= Variables: Storing Information 📦

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    *Variables are like boxes that hold data:*
    
    #v(1em)
    
    #box(fill: yellow.lighten(70%), inset: 1em, radius: 5pt)[
      ```python
      bird_x = 100
      bird_y = 200
      velocity = 0
      score = 0
      game_over = False
      ```
    ]
    
    #v(1em)
    
    - Numbers (integers & decimals)
    - Text (strings)
    - True/False (booleans)
    - Lists of things
  ],
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.24.58 AM.png", height: 320pt)
    ]
  ]
)

#pagebreak()

// Slide 15: If Statements
#v(1em)
= If Statements: Making Decisions 🤔

#text(size: 24pt)[
  *The game makes hundreds of decisions every second!*
]

#v(1em)

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    #box(fill: green.lighten(80%), inset: 1em, radius: 5pt)[
      ```python
      if space_pressed:
          bird.jump()
      
      if bird hits pipe:
          game_over = True
      
      if bird passed pipe:
          score += 1
      
      if score > high_score:
          high_score = score
          save_to_file()
      ```
    ]
  ],
  [
    *Questions to think about:*
    
    - What happens if the bird falls below the ground?
    - What happens if the bird flies too high?
    - How does the game know when to spawn a new pipe?
    - What happens when you press space during game over?
    
    #v(1em)
    
    #text(size: 18pt, fill: blue)[
      *Look for these "if" statements in the code!*
    ]
  ]
)

#pagebreak()

// Slide 16: Your Turn
#v(1em)
= Your Turn: Code Investigation! 🔍

#text(size: 24pt)[
  *Now it's time to explore the actual code!*
]

#v(1em)

#grid(
  columns: (1fr, 1fr),
  gutter: 2em,
  [
    *You'll discover:*
    
    - How variables store game data
    - How if statements make decisions
    - How loops repeat actions
    - How lists manage multiple objects
    - How math creates realistic motion
    
    #v(1em)
    
    *Tips:*
    
    - Start with the small files
    - Look for familiar patterns
    - Try changing values
    - Don't be afraid to experiment!
  ],
  [
    #align(center)[
      #image("assets/Screenshot 2025-12-06 at 10.30.54 AM.png", height: 320pt)
    ]
  ]
)

#pagebreak()

// Slide 17: Final Slide
#align(center + horizon)[
  #text(size: 48pt, weight: "bold")[
    Ready to Begin?
  ]
  
  #v(2em)
  
  #text(size: 32pt)[
    Open your assignment and start exploring!
  ]
  
  #v(2em)
  
  #text(size: 24pt, fill: blue)[
    Remember: Real programmers learn by reading and experimenting with code!
  ]
  
  #v(2em)
  
  #text(size: 28pt)[
    🎮 Have fun! 🚀
  ]
]
