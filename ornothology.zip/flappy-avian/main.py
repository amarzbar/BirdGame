"""
Main entry point for Flappy Bird game.
Run this file to start the game.
"""

import tkinter as tk
from game import FlappyBirdGame


def main():
    """Initialize and run the game."""
    # Create root window
    root = tk.Tk()
    
    # Create game instance
    game = FlappyBirdGame(root)
    
    # Start main loop
    root.mainloop()


if __name__ == '__main__':
    main()
