"""
Pipe class module.
Handles pipe obstacles, their movement, and rendering.
"""

import random
import config


class Pipe:
    """Represents a pair of pipes (top and bottom)."""
    
    def __init__(self, x):
        """Initialize a pipe pair.
        
        Args:
            x: Initial x position of the pipe
        """
        self.x = x
        self.width = config.PIPE_WIDTH
        self.gap = config.PIPE_GAP
        self.scored = False  # Track if bird has passed this pipe
        
        # Randomize gap position
        self._randomize_gap_position()
    
    def _randomize_gap_position(self):
        """Randomize the vertical position of the gap between pipes."""
        # Calculate valid range for gap center
        min_gap_center = config.MIN_PIPE_HEIGHT + self.gap // 2
        max_gap_center = (config.WINDOW_HEIGHT - config.GROUND_HEIGHT - 
                         config.MIN_PIPE_HEIGHT - self.gap // 2)
        
        # Set gap center position
        self.gap_center = random.randint(min_gap_center, max_gap_center)
        
        # Calculate top and bottom pipe heights
        self.top_height = self.gap_center - self.gap // 2
        self.bottom_y = self.gap_center + self.gap // 2
    
    def update(self):
        """Update pipe position (move left)."""
        self.x -= config.PIPE_SPEED
    
    def is_off_screen(self):
        """Check if pipe has moved off the left side of screen.
        
        Returns:
            True if pipe is completely off screen
        """
        return self.x + self.width < 0
    
    def get_rects(self):
        """Get bounding rectangles for collision detection.
        
        Returns:
            Tuple of (top_rect, bottom_rect) where each rect is (x, y, width, height)
        """
        top_rect = (
            self.x,
            0,
            self.width,
            self.top_height
        )
        
        bottom_rect = (
            self.x,
            self.bottom_y,
            self.width,
            config.WINDOW_HEIGHT - config.GROUND_HEIGHT - self.bottom_y
        )
        
        return (top_rect, bottom_rect)
    
    def render(self, canvas, pipe_image=None, pipe_top_image=None):
        """Render the pipe pair on the canvas.
        
        Args:
            canvas: tkinter Canvas object
            pipe_image: Optional PhotoImage for the bottom pipe sprite
            pipe_top_image: Optional PhotoImage for the top pipe sprite (rotated)
        """
        # Use rotated image for top pipe if available, otherwise use regular
        top_image = pipe_top_image if pipe_top_image else pipe_image
        
        if top_image:
            # Draw top pipe (using rotated image)
            canvas.create_image(
                self.x + self.width // 2,
                self.top_height,
                image=top_image,
                anchor='s'  # Anchor at bottom of image
            )
        else:
            # Fallback: draw green rectangle for top pipe
            canvas.create_rectangle(
                self.x,
                0,
                self.x + self.width,
                self.top_height,
                fill='#72D543',
                outline='#5CB32E',
                width=2
            )
        
        if pipe_image:
            # Draw bottom pipe
            canvas.create_image(
                self.x + self.width // 2,
                self.bottom_y,
                image=pipe_image,
                anchor='n'  # Anchor at top of image
            )
        else:
            # Fallback: draw green rectangle for bottom pipe
            canvas.create_rectangle(
                self.x,
                self.bottom_y,
                self.x + self.width,
                config.WINDOW_HEIGHT - config.GROUND_HEIGHT,
                fill='#72D543',
                outline='#5CB32E',
                width=2
            )


class PipeManager:
    """Manages multiple pipes."""
    
    def __init__(self):
        """Initialize the pipe manager."""
        self.pipes = []
        self.spawn_timer = 0
    
    def reset(self):
        """Reset all pipes."""
        self.pipes = []
        self.spawn_timer = 0
        # Spawn initial pipe
        self.pipes.append(Pipe(config.WINDOW_WIDTH))
    
    def update(self):
        """Update all pipes and spawn new ones as needed."""
        # Update existing pipes
        for pipe in self.pipes:
            pipe.update()
        
        # Remove off-screen pipes
        self.pipes = [p for p in self.pipes if not p.is_off_screen()]
        
        # Spawn new pipes
        if not self.pipes or self.pipes[-1].x < config.WINDOW_WIDTH - config.PIPE_SPAWN_DISTANCE:
            self.pipes.append(Pipe(config.WINDOW_WIDTH))
    
    def render(self, canvas, pipe_image=None, pipe_top_image=None):
        """Render all pipes.
        
        Args:
            canvas: tkinter Canvas object
            pipe_image: Optional PhotoImage for the bottom pipe sprite
            pipe_top_image: Optional PhotoImage for the top pipe sprite (rotated)
        """
        for pipe in self.pipes:
            pipe.render(canvas, pipe_image, pipe_top_image)
    
    def check_scoring(self, bird_x):
        """Check if bird has passed any pipes for scoring.
        
        Args:
            bird_x: X position of the bird
            
        Returns:
            Number of pipes scored (0 or 1)
        """
        score_gained = 0
        for pipe in self.pipes:
            if not pipe.scored and bird_x > pipe.x + pipe.width:
                pipe.scored = True
                score_gained += 1
        return score_gained
