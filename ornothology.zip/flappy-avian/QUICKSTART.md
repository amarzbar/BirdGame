# Quick Reference Guide

## Installation

```bash
# Install dependencies
pip install Pillow

# Or use setup script
python setup.py

# Run game
python main.py
```

## Controls

| Key | Action |
|-----|--------|
| `ENTER` | Start game from menu |
| `SPACE` | Make bird jump (needs implementation!) |
| `R` | Restart after game over |

## File Overview

| File | Lines | Purpose |
|------|-------|---------|
| `main.py` | 23 | Entry point |
| `game.py` | 311 | Game loop & state management |
| `bird.py` | 108 | Bird physics & rendering |
| `pipe.py` | 175 | Pipe obstacles |
| `collision.py` | 106 | Collision detection |
| `score_manager.py` | 113 | Score tracking |
| `assets.py` | 143 | Asset loading |
| `config.py` | 56 | Constants |

## Key Constants (config.py)

```python
# Physics
GRAVITY = 0.5           # Downward acceleration
JUMP_VELOCITY = -9.0    # Upward velocity on jump
MAX_FALL_SPEED = 10.0   # Terminal velocity

# Window
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 600
FPS = 60

# Pipes
PIPE_WIDTH = 70
PIPE_GAP = 180          # Gap between top/bottom pipe
PIPE_SPEED = 3          # Horizontal movement speed
PIPE_SPAWN_DISTANCE = 200  # Distance between pipe pairs
```

## Exercise: Implement Bird Jump

**Location**: `bird.py`, line ~53

**What to do**: Replace `pass` with one line of code

**Hint**: Set `self.velocity` to `config.JUMP_VELOCITY`

## Testing Your Implementation

1. Run: `python main.py`
2. Press `ENTER` to start
3. Press `SPACE` to jump
4. Bird should jump up and fall down
5. Navigate through pipes to score

## Common Issues

### PIL Import Error
```bash
pip install Pillow
```

### No tkinter
- **macOS/Windows**: Pre-installed
- **Linux**: `sudo apt-get install python3-tk`

### Sprites Not Loading
- Check internet connection
- Sprites auto-downloaded on first run
- Cached in `assets/` folder
- Fallback to colored shapes if download fails

## Game States

1. **MENU**: Press ENTER to start
2. **PLAYING**: Navigate through pipes
3. **GAME_OVER**: Press R to restart

## Scoring

- **+1 point** per pipe passed
- **High score** saved in `highscore.txt`
- **Random bird color** each game

## Project Structure

```
flappy-avian/
├── main.py              # Run this!
├── game.py              # Game logic
├── bird.py              # ⚠️ Implement jump here
├── pipe.py              # Obstacles
├── collision.py         # Collision detection
├── score_manager.py     # Scoring
├── assets.py            # Asset loading
├── config.py            # Constants
├── setup.py             # Dependency checker
├── requirements.txt     # Dependencies
├── README.md            # Full documentation
├── SOLUTION.md          # Solution (spoilers!)
├── PROJECT_SUMMARY.md   # Detailed overview
└── ARCHITECTURE.md      # System design
```

## Quick Tips

### Make Jump Higher
In `config.py`: `JUMP_VELOCITY = -10.0`

### Make Game Easier
In `config.py`: `PIPE_GAP = 200` and `PIPE_SPEED = 2`

### Make Game Harder
In `config.py`: `PIPE_GAP = 160` and `PIPE_SPEED = 4`

## Getting Help

1. **Read README.md** for full documentation
2. **Check ARCHITECTURE.md** for system design
3. **Review SOLUTION.md** if stuck (but try yourself first!)
4. **Look at PROJECT_SUMMARY.md** for implementation details

## Success Criteria

✅ Game runs without errors  
✅ Bird jumps on spacebar  
✅ Bird falls due to gravity  
✅ Can navigate through pipes  
✅ Score increases correctly  
✅ Game ends on collision  
✅ High score persists  
✅ Bird color changes each game  

## Code Quality

- Total: **1,035 lines** across 8 files
- Largest file: **311 lines** (game.py)
- All files: **< 1000 lines** ✅
- Modular: **Single responsibility** ✅
- Well-commented: **Extensive docs** ✅

## Have Fun! 🎮

Remember: The goal is to learn, not just complete!

Take your time understanding how each module works together.

**Happy Coding!** 🚀
