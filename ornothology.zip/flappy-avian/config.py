"""
Game configuration constants.
Contains all game settings, dimensions, speeds, and asset URLs.
"""

# Window dimensions
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 600
FPS = 60

# Game physics
GRAVITY = 0.5
JUMP_VELOCITY = -9.0  # Negative because Y increases downward
MAX_FALL_SPEED = 100.0
BIRD_SIZE = 34

# Pipe settings
PIPE_WIDTH = 70
PIPE_GAP = 180
PIPE_SPEED = 3
PIPE_SPAWN_DISTANCE = 200  # Distance between pipes
MIN_PIPE_HEIGHT = 100
MAX_PIPE_HEIGHT = 400

# Ground
GROUND_HEIGHT = 100
GROUND_SPEED = 3

# Colors for randomizing bird
BIRD_COLORS = [
    '#FF6B6B',  # Red
    '#4ECDC4',  # Teal
    '#FFE66D',  # Yellow
    '#95E1D3',  # Mint
    '#F38181',  # Pink
    '#AA96DA',  # Purple
    '#FCBAD3',  # Light Pink
    '#A8D8EA',  # Sky Blue
]

# Asset URLs (using placeholder images from online)
ASSET_URLS = {
    'background': 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/background-day.png',
    'ground': 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/base.png',
    'pipe': 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/pipe-green.png',
    'bird': 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/yellowbird-midflap.png',
}

# File paths
ASSETS_DIR = 'assets'
HIGH_SCORE_FILE = 'highscore.txt'

# Game states
STATE_MENU = 'menu'
STATE_PLAYING = 'playing'
STATE_GAME_OVER = 'game_over'
