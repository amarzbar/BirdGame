"""
Bird class module.
Handles the bird's physics, rendering, and state.
"""

import random
import config


class Bird:
    """Represents the player-controlled bird."""
    
    def __init__(self, x, y):
        """Initialize the bird.
        
        Args:
            x: Initial x position
            y: Initial y position
        """
        self.x = x
        self.y = y
        self.velocity = 0
        self.size = config.BIRD_SIZE
        self.color = random.choice(config.BIRD_COLORS)
        self.rotation = 0
    
    def update(self):
        """Update bird physics (gravity and velocity).
        
        This method handles the bird's movement including:
        - Applying gravity to velocity
        - Updating position based on velocity
        - Clamping maximum fall speed
        - Calculating rotation based on velocity
        """
        # Apply gravity
        self.velocity += config.GRAVITY
        
        # Clamp maximum fall speed
        if self.velocity > config.MAX_FALL_SPEED:
            self.velocity = config.MAX_FALL_SPEED
        
        # Update position
        self.y += self.velocity
        
        # Calculate rotation based on velocity (for visual effect)
        # Upward movement rotates bird up, downward rotates bird down
        self.rotation = max(-25, min(25, -self.velocity * 3))
    
    def jump(self):
        """Make the bird jump.
        
        Update the bird's velocity for a jump.
        """
        # TODO: Make the bird jump!
        # Hint: Set self.velocity controls the speed (velocity of the bird, maybe we can give it a new value but which value?)
        # Hint : I won't accept "Magic numbers", use check the config file for a suitable constant
        pass
    
    def get_rect(self):
        """Get the bird's bounding rectangle for collision detection.
        
        Returns:
            Tuple of (x, y, width, height)
        """
        return (
            self.x - self.size // 2,
            self.y - self.size // 2,
            self.size,
            self.size
        )
    
    def render(self, canvas, bird_image=None):
        """Render the bird on the canvas.
        
        Args:
            canvas: tkinter Canvas object
            bird_image: Optional PhotoImage for the bird sprite
        """
        x1 = self.x - self.size // 2
        y1 = self.y - self.size // 2
        x2 = self.x + self.size // 2
        y2 = self.y + self.size // 2
        
        if bird_image:
            # Draw sprite (note: rotation would require more complex PIL operations)
            canvas.create_image(self.x, self.y, image=bird_image)
        else:
            # Fallback: draw colored oval
            canvas.create_oval(x1, y1, x2, y2, fill=self.color, outline='black', width=2)
    
    def reset(self, x, y):
        """Reset the bird to initial state.
        
        Args:
            x: Reset x position
            y: Reset y position
        """
        self.x = x
        self.y = y
        self.velocity = 0
        self.rotation = 0
        self.color = random.choice(config.BIRD_COLORS)
