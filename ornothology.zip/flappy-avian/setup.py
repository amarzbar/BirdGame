#!/usr/bin/env python3
"""
Quick setup script for Flappy Bird Clone.
Installs dependencies and provides helpful information.
"""

import subprocess
import sys


def check_tkinter():
    """Check if tkinter is available."""
    try:
        import tkinter
        print("✓ tkinter is installed")
        return True
    except ImportError:
        print("✗ tkinter is NOT installed")
        print("  Install instructions:")
        print("  - macOS/Windows: Should be pre-installed")
        print("  - Linux: sudo apt-get install python3-tk")
        return False


def install_pillow():
    """Install Pillow package."""
    print("\nInstalling Pillow...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow>=10.0.0"])
        print("✓ Pillow installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("✗ Failed to install Pillow")
        print("  Try manually: pip install Pillow")
        return False


def check_pillow():
    """Check if Pillow is available."""
    try:
        import PIL
        print("✓ Pillow is installed")
        return True
    except ImportError:
        print("✗ Pillow is NOT installed")
        return False


def main():
    """Run setup checks and installations."""
    print("=" * 50)
    print("Flappy Bird Clone - Setup Script")
    print("=" * 50)
    
    print("\nChecking dependencies...\n")
    
    # Check tkinter
    tkinter_ok = check_tkinter()
    
    # Check/install Pillow
    pillow_ok = check_pillow()
    if not pillow_ok:
        user_input = input("\nWould you like to install Pillow now? (y/n): ")
        if user_input.lower() in ['y', 'yes']:
            pillow_ok = install_pillow()
    
    # Summary
    print("\n" + "=" * 50)
    if tkinter_ok and pillow_ok:
        print("✓ All dependencies are ready!")
        print("\nYou can now run the game with:")
        print("  python main.py")
        print("\nREMEMBER: The jump function is not implemented!")
        print("Check bird.py and implement the jump() method.")
    else:
        print("✗ Some dependencies are missing.")
        print("Please install them before running the game.")
    print("=" * 50)


if __name__ == '__main__':
    main()
